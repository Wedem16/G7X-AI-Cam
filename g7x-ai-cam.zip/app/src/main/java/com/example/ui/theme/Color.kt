package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Samsung One UI Camera & Canon G7X Warm Xenon Amber Palette
val AmberGold = Color(0xFFFFB800)
val AmberGoldLight = Color(0xFFFFD54F)
val AmberGoldContainer = Color(0xFF3A2A00)
val OnAmberGold = Color(0xFF1F1600)

val CameraObsidian = Color(0xFF090A0D)
val CameraSurfaceDark = Color(0xFF14171F)
val CameraSurfaceElevated = Color(0xFF1F2430)
val CameraGlassScrim = Color(0xB310131A)

val LightBackground = Color(0xFFF7F8FA)
val LightSurface = Color(0xFFFFFFFF)
val AmberPrimaryLight = Color(0xFFB27D00)

val ErrorCoral = Color(0xFFFF6B6B)
val SuccessMint = Color(0xFF4ADE80)
