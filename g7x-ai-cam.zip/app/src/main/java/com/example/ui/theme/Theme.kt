package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
  primary = AmberGold,
  onPrimary = OnAmberGold,
  primaryContainer = AmberGoldContainer,
  onPrimaryContainer = AmberGoldLight,
  secondary = AmberGoldLight,
  onSecondary = OnAmberGold,
  tertiary = SuccessMint,
  background = CameraObsidian,
  onBackground = Color(0xFFF3F4F6),
  surface = CameraSurfaceDark,
  onSurface = Color(0xFFF3F4F6),
  surfaceVariant = CameraSurfaceElevated,
  onSurfaceVariant = Color(0xFFD1D5DB),
  error = ErrorCoral,
)

private val LightColorScheme = lightColorScheme(
  primary = AmberPrimaryLight,
  onPrimary = Color.White,
  primaryContainer = Color(0xFFFFECB3),
  onPrimaryContainer = Color(0xFF261900),
  secondary = Color(0xFF544519),
  onSecondary = Color.White,
  tertiary = Color(0xFF15803D),
  background = LightBackground,
  onBackground = Color(0xFF111827),
  surface = LightSurface,
  onSurface = Color(0xFF111827),
  surfaceVariant = Color(0xFFE5E7EB),
  onSurfaceVariant = Color(0xFF374151),
  error = Color(0xFFDC2626),
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content,
  )
}
