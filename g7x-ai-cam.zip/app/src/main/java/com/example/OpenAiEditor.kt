package com.example

import android.util.Base64
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONObject

/**
 * Handles sending captured photos to the OpenAI Images Edit API (`POST /v1/images/edits`)
 * using model `gpt-image-1` and `input_fidelity = high` to apply the Canon G7X flash aesthetic.
 */
object OpenAiEditor {

  const val ENDPOINT_URL = "https://api.openai.com/v1/images/edits"
  const val MODEL_NAME = "gpt-image-1"
  const val INPUT_FIDELITY = "high"

  const val CANON_G7X_PROMPT =
    "Make this photo look like it was taken using a Canon G7X with the flash on. " +
      "Do not change my face, features, body proportions, or the original background"

  private val httpClient: OkHttpClient by lazy {
    OkHttpClient.Builder()
      .connectTimeout(60, TimeUnit.SECONDS)
      .writeTimeout(90, TimeUnit.SECONDS)
      .readTimeout(120, TimeUnit.SECONDS)
      .build()
  }

  /**
   * Checks whether [rawKey] looks like a user-provided OpenAI API key (`sk-...`)
   * rather than an empty string or an environment placeholder token (`key_...`).
   */
  fun isValidOpenAiKeyFormat(rawKey: String): Boolean {
    val trimmed = rawKey.trim()
    return trimmed.startsWith("sk-") && trimmed.length > 12
  }

  /**
   * Uploads [imageFile] as `multipart/form-data` to the OpenAI Images Edit endpoint and decodes
   * the returned `b64_json` image payload into raw bytes ready to save to MediaStore.
   *
   * @throws IOException if the network call fails, returns a non-2xx code, or lacks `b64_json`.
   */
  suspend fun editPhotoWithCanonG7xFlash(
    imageFile: File,
    apiKey: String,
    prompt: String = CANON_G7X_PROMPT,
  ): ByteArray =
    withContext(Dispatchers.IO) {
      val trimmedKey = apiKey.trim()
      if (trimmedKey.isEmpty()) {
        throw IOException("Missing OpenAI API key. Tap 'API Key' to paste your sk-... key.")
      }
      if (!isValidOpenAiKeyFormat(trimmedKey)) {
        throw IOException("Invalid OpenAI API key format (must start with 'sk-'). Tap 'API Key' to update.")
      }
      if (!imageFile.exists() || imageFile.length() == 0L) {
        throw IOException("Captured image file is empty or missing.")
      }

      val mediaType = "image/jpeg".toMediaType()
      val requestBody =
        MultipartBody.Builder()
          .setType(MultipartBody.FORM)
          .addFormDataPart("model", MODEL_NAME)
          .addFormDataPart("prompt", prompt)
          .addFormDataPart("input_fidelity", INPUT_FIDELITY)
          .addFormDataPart("image", imageFile.name, imageFile.asRequestBody(mediaType))
          .build()

      val request =
        Request.Builder()
          .url(ENDPOINT_URL)
          .addHeader("Authorization", "Bearer $trimmedKey")
          .post(requestBody)
          .build()

      httpClient.newCall(request).execute().use { response ->
        val rawBody = response.body?.string().orEmpty()
        if (!response.isSuccessful) {
          val apiErrorMsg = parseErrorMessage(rawBody, response.code)
          throw IOException(apiErrorMsg)
        }

        val json = JSONObject(rawBody)
        val dataArray = json.optJSONArray("data")
        if (dataArray == null || dataArray.length() == 0) {
          throw IOException("OpenAI response did not include an image data array.")
        }

        val firstItem = dataArray.getJSONObject(0)
        val b64Json = firstItem.optString("b64_json", "")
        if (b64Json.isBlank()) {
          throw IOException("OpenAI response did not contain b64_json image bytes.")
        }

        try {
          Base64.decode(b64Json, Base64.DEFAULT)
        } catch (e: IllegalArgumentException) {
          throw IOException("Failed to decode b64_json image payload: ${e.message}", e)
        }
      }
    }

  private fun parseErrorMessage(rawBody: String, statusCode: Int): String {
    return try {
      val json = JSONObject(rawBody)
      val errorObj = json.optJSONObject("error")
      val message = errorObj?.optString("message").orEmpty()
      when {
        statusCode == 401 ->
          "Invalid OpenAI API key (401). Please tap 'API Key' and paste a valid sk-... key."
        message.isNotBlank() ->
          "OpenAI API error ($statusCode): $message"
        else ->
          "OpenAI HTTP $statusCode"
      }
    } catch (_: Exception) {
      if (statusCode == 401) {
        "Invalid OpenAI API key (401). Please tap 'API Key' and paste a valid sk-... key."
      } else {
        "OpenAI HTTP $statusCode"
      }
    }
  }
}
