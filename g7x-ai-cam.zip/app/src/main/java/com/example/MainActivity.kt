package com.example

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.FlipCameraAndroid
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.ui.theme.AmberGold
import com.example.ui.theme.CameraGlassScrim
import com.example.ui.theme.CameraObsidian
import com.example.ui.theme.ErrorCoral
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.SuccessMint
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val PREFS_NAME = "g7x_ai_cam_prefs"
private const val KEY_OPENAI_API_KEY = "openai_api_key"
private const val TAG = "G7xAiCam"

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        Surface(
          modifier = Modifier.fillMaxSize(),
          color = MaterialTheme.colorScheme.background,
        ) {
          G7xCameraApp()
        }
      }
    }
  }
}

@Composable
fun G7xCameraApp() {
  val context = LocalContext.current
  var hasCameraPermission by remember {
    mutableStateOf(
      ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
        PackageManager.PERMISSION_GRANTED
    )
  }
  var permissionRequestedOnce by rememberSaveable { mutableStateOf(false) }

  val permissionLauncher =
    rememberLauncherForActivityResult(
      contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
      hasCameraPermission = granted
      permissionRequestedOnce = true
    }

  LaunchedEffect(Unit) {
    if (!hasCameraPermission) {
      permissionLauncher.launch(Manifest.permission.CAMERA)
    }
  }

  if (hasCameraPermission) {
    SamsungStyleCameraScreen()
  } else {
    CameraPermissionScreen(
      permissionRequestedOnce = permissionRequestedOnce,
      onRequestPermission = { permissionLauncher.launch(Manifest.permission.CAMERA) },
      onOpenSettings = {
        val intent =
          Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", context.packageName, null)
          }
        context.startActivity(intent)
      },
    )
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SamsungStyleCameraScreen() {
  val context = LocalContext.current
  val lifecycleOwner = LocalLifecycleOwner.current
  val coroutineScope = rememberCoroutineScope()

  val prefs = remember { context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE) }

  // Load locally stored OpenAI API key (ignoring any non-OpenAI placeholder tokens)
  var apiKey by remember {
    val savedKey = prefs.getString(KEY_OPENAI_API_KEY, "")?.trim().orEmpty()
    val validSavedKey =
      if (OpenAiEditor.isValidOpenAiKeyFormat(savedKey)) {
        savedKey
      } else {
        if (savedKey.isNotEmpty()) {
          prefs.edit().remove(KEY_OPENAI_API_KEY).apply()
        }
        ""
      }
    mutableStateOf(validSavedKey)
  }

  var isFlashOn by rememberSaveable { mutableStateOf(true) }
  var isAiEnabled by rememberSaveable { mutableStateOf(true) }
  var lensFacing by rememberSaveable { mutableIntStateOf(CameraSelector.LENS_FACING_BACK) }
  var isProcessing by rememberSaveable { mutableStateOf(false) }

  var statusMessage by rememberSaveable { mutableStateOf("") }
  var statusDetail by rememberSaveable { mutableStateOf("") }
  var isStatusError by rememberSaveable { mutableStateOf(false) }
  var showShutterFlashOverlay by remember { mutableStateOf(false) }

  var showApiKeyDialog by rememberSaveable { mutableStateOf(false) }
  var showPromptInfoDialog by rememberSaveable { mutableStateOf(false) }
  var showLastPhotoDialog by rememberSaveable { mutableStateOf(false) }

  var lastSavedBitmap by remember { mutableStateOf<Bitmap?>(null) }
  var lastSavedWasAiEdited by rememberSaveable { mutableStateOf(false) }

  val previewView = remember {
    PreviewView(context).apply {
      implementationMode = PreviewView.ImplementationMode.COMPATIBLE
      scaleType = PreviewView.ScaleType.FILL_CENTER
    }
  }

  val imageCapture = remember {
    ImageCapture.Builder()
      .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
      .setFlashMode(ImageCapture.FLASH_MODE_ON)
      .build()
  }

  // Keep flash mode synchronized with UI state
  LaunchedEffect(isFlashOn) {
    imageCapture.flashMode =
      if (isFlashOn) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF
  }

  // Bind CameraX Preview + ImageCapture to lifecycle whenever lensFacing changes
  LaunchedEffect(lensFacing) {
    try {
      val cameraProvider = context.getCameraProvider()
      val preview =
        Preview.Builder().build().also {
          it.surfaceProvider = previewView.surfaceProvider
        }
      imageCapture.flashMode =
        if (isFlashOn) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF

      val requestedSelector =
        CameraSelector.Builder().requireLensFacing(lensFacing).build()

      cameraProvider.unbindAll()
      if (cameraProvider.hasCamera(requestedSelector)) {
        cameraProvider.bindToLifecycle(
          lifecycleOwner,
          requestedSelector,
          preview,
          imageCapture,
        )
      } else if (cameraProvider.hasCamera(CameraSelector.DEFAULT_BACK_CAMERA)) {
        cameraProvider.bindToLifecycle(
          lifecycleOwner,
          CameraSelector.DEFAULT_BACK_CAMERA,
          preview,
          imageCapture,
        )
      } else if (cameraProvider.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA)) {
        cameraProvider.bindToLifecycle(
          lifecycleOwner,
          CameraSelector.DEFAULT_FRONT_CAMERA,
          preview,
          imageCapture,
        )
      }
    } catch (e: Exception) {
      Log.w(TAG, "CameraX binding warning: ${e.message}")
    }
  }

  DisposableEffect(Unit) {
    onDispose {
      try {
        ProcessCameraProvider.getInstance(context).get().unbindAll()
      } catch (_: Exception) {}
    }
  }

  Box(
    modifier =
      Modifier.fillMaxSize()
        .background(CameraObsidian)
        .testTag("camera_screen_root")
  ) {
    // 1. Full-screen Live CameraX Preview
    AndroidView(
      factory = { previewView },
      modifier =
        Modifier.fillMaxSize()
          .testTag("camera_preview_view"),
    )

    // Subtle top and bottom Samsung One UI viewfinder gradient scrims for high contrast
    Box(
      modifier =
        Modifier.fillMaxWidth()
          .height(140.dp)
          .align(Alignment.TopCenter)
          .background(
            Brush.verticalGradient(
              colors = listOf(Color.Black.copy(alpha = 0.72f), Color.Transparent)
            )
          )
    )

    Box(
      modifier =
        Modifier.fillMaxWidth()
          .height(310.dp)
          .align(Alignment.BottomCenter)
          .background(
            Brush.verticalGradient(
              colors =
                listOf(
                  Color.Transparent,
                  Color.Black.copy(alpha = 0.78f),
                  Color.Black.copy(alpha = 0.94f),
                )
            )
          )
    )

    // Brief white/warm amber flash overlay on capture
    AnimatedVisibility(
      visible = showShutterFlashOverlay,
      enter = fadeIn(),
      exit = fadeOut(),
      modifier = Modifier.fillMaxSize(),
    ) {
      Box(
        modifier =
          Modifier.fillMaxSize()
            .background(Color(0xFFFFF8E7).copy(alpha = 0.75f))
      )
    }

    // 2. Top Viewfinder Status Header
    Row(
      modifier =
        Modifier.fillMaxWidth()
          .windowInsetsPadding(WindowInsets.statusBars)
          .padding(horizontal = 16.dp, vertical = 12.dp)
          .align(Alignment.TopCenter),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      // Canon G7X Mode Pill
      Surface(
        color = CameraGlassScrim,
        shape = RoundedCornerShape(50),
        border =
          BorderStroke(
            width = 1.dp,
            color =
              if (isAiEnabled) AmberGold.copy(alpha = 0.7f)
              else Color.White.copy(alpha = 0.25f),
          ),
        modifier =
          Modifier.minimumInteractiveComponentSize()
            .clip(RoundedCornerShape(50))
            .clickable { showPromptInfoDialog = true }
            .semantics {
              role = Role.Button
              contentDescription =
                if (isAiEnabled) {
                  "Canon G7X Flash AI filter active. Double tap to view prompt details"
                } else {
                  "Standard photo mode active. Double tap to view prompt details"
                }
            }
            .testTag("mode_info_pill"),
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Box(
            modifier =
              Modifier.size(8.dp)
                .clip(CircleShape)
                .background(if (isAiEnabled) AmberGold else Color.LightGray)
          )
          Text(
            text =
              if (isAiEnabled) stringResource(R.string.camera_mode_badge)
              else stringResource(R.string.camera_mode_raw_badge),
            style = MaterialTheme.typography.labelLarge,
            color = if (isAiEnabled) AmberGold else Color.White,
          )
          Icon(
            imageVector = Icons.Outlined.Info,
            contentDescription = null,
            tint = Color.White.copy(alpha = 0.8f),
            modifier = Modifier.size(16.dp),
          )
        }
      }

      // API Key Status Badge
      val hasKey = OpenAiEditor.isValidOpenAiKeyFormat(apiKey)
      Surface(
        color = CameraGlassScrim,
        shape = RoundedCornerShape(50),
        border =
          BorderStroke(
            width = 1.dp,
            color =
              if (hasKey) SuccessMint.copy(alpha = 0.6f)
              else ErrorCoral.copy(alpha = 0.6f),
          ),
        modifier =
          Modifier.minimumInteractiveComponentSize()
            .clip(RoundedCornerShape(50))
            .clickable { showApiKeyDialog = true }
            .semantics {
              role = Role.Button
              contentDescription =
                if (hasKey) {
                  "API key ready. Double tap to update OpenAI API key"
                } else {
                  "API key missing. Double tap to paste OpenAI API key"
                }
            }
            .testTag("top_api_key_badge"),
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          Icon(
            imageVector = if (hasKey) Icons.Filled.CheckCircle else Icons.Filled.Key,
            contentDescription = null,
            tint = if (hasKey) SuccessMint else ErrorCoral,
            modifier = Modifier.size(15.dp),
          )
          Text(
            text = if (hasKey) "Key Ready" else "Set Key",
            style = MaterialTheme.typography.labelLarge,
            color = Color.White,
          )
        }
      }
    }

    // 3. Bottom Samsung-style Camera Deck: Live Status Banner + 4 Control Buttons + Big Round Shutter
    Column(
      modifier =
        Modifier.fillMaxWidth()
          .widthIn(max = 600.dp)
          .align(Alignment.BottomCenter)
          .windowInsetsPadding(WindowInsets.navigationBars)
          .padding(horizontal = 16.dp, vertical = 16.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      // Accessible Live Region Status Pill ("Capturing...", "AI editing your photo...", "Saved", or error)
      val displayedStatus =
        if (statusMessage.isNotBlank()) statusMessage
        else stringResource(R.string.status_ready)

      Surface(
        color =
          when {
            isStatusError -> Color(0xCC3B1014)
            isProcessing -> Color(0xCC291F04)
            statusMessage == stringResource(R.string.status_saved) -> Color(0xCC0D2E1B)
            else -> CameraGlassScrim
          },
        shape = RoundedCornerShape(20.dp),
        border =
          BorderStroke(
            width = 1.dp,
            color =
              when {
                isStatusError -> ErrorCoral.copy(alpha = 0.75f)
                isProcessing -> AmberGold.copy(alpha = 0.75f)
                statusMessage == stringResource(R.string.status_saved) ->
                  SuccessMint.copy(alpha = 0.75f)
                else -> Color.White.copy(alpha = 0.18f)
              },
          ),
        modifier =
          Modifier.fillMaxWidth()
            .semantics {
              liveRegion = LiveRegionMode.Polite
              contentDescription =
                if (statusDetail.isNotBlank()) "$displayedStatus. $statusDetail"
                else displayedStatus
            }
            .testTag("status_live_region"),
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.Center,
        ) {
          if (isProcessing) {
            CircularProgressIndicator(
              modifier = Modifier.size(18.dp),
              strokeWidth = 2.dp,
              color = AmberGold,
            )
            Spacer(modifier = Modifier.width(10.dp))
          } else if (isStatusError) {
            Icon(
              imageVector = Icons.Filled.ErrorOutline,
              contentDescription = null,
              tint = ErrorCoral,
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
          } else if (statusMessage == stringResource(R.string.status_saved)) {
            Icon(
              imageVector = Icons.Filled.CheckCircle,
              contentDescription = null,
              tint = SuccessMint,
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
          }

          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
              text = displayedStatus,
              style = MaterialTheme.typography.titleMedium,
              color =
                when {
                  isStatusError -> Color(0xFFFFB4B4)
                  isProcessing -> AmberGold
                  statusMessage == stringResource(R.string.status_saved) -> SuccessMint
                  else -> Color.White
                },
              textAlign = TextAlign.Center,
            )
            if (statusDetail.isNotBlank()) {
              Text(
                text = statusDetail,
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White.copy(alpha = 0.85f),
                textAlign = TextAlign.Center,
              )
            }
          }
        }
      }

      // Row of 4 Camera Control Buttons above the Capture Button:
      // Flash | AI On/Off | Flip camera | API Key
      Surface(
        color = CameraGlassScrim,
        shape = RoundedCornerShape(28.dp),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.14f)),
        modifier = Modifier.fillMaxWidth(),
      ) {
        FlowRow(
          modifier =
            Modifier.fillMaxWidth()
              .padding(horizontal = 8.dp, vertical = 8.dp),
          horizontalArrangement = Arrangement.SpaceEvenly,
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          // 1. Flash Button
          CameraControlPillButton(
            icon = if (isFlashOn) Icons.Filled.FlashOn else Icons.Filled.FlashOff,
            label =
              if (isFlashOn) stringResource(R.string.label_flash_on)
              else stringResource(R.string.label_flash_off),
            isActive = isFlashOn,
            contentDescriptionText =
              if (isFlashOn) stringResource(R.string.cd_flash_on)
              else stringResource(R.string.cd_flash_off),
            testTag = "flash_button",
            onClick = { isFlashOn = !isFlashOn },
          )

          // 2. AI On/Off Button
          CameraControlPillButton(
            icon = if (isAiEnabled) Icons.Filled.AutoAwesome else Icons.Outlined.AutoAwesome,
            label =
              if (isAiEnabled) stringResource(R.string.label_ai_on)
              else stringResource(R.string.label_ai_off),
            isActive = isAiEnabled,
            contentDescriptionText =
              if (isAiEnabled) stringResource(R.string.cd_ai_on)
              else stringResource(R.string.cd_ai_off),
            testTag = "ai_toggle_button",
            onClick = { isAiEnabled = !isAiEnabled },
          )

          // 3. Flip Camera Button
          val isBackCamera = lensFacing == CameraSelector.LENS_FACING_BACK
          CameraControlPillButton(
            icon = Icons.Filled.FlipCameraAndroid,
            label = stringResource(R.string.label_flip_camera),
            isActive = false,
            contentDescriptionText =
              if (isBackCamera) stringResource(R.string.cd_flip_back)
              else stringResource(R.string.cd_flip_front),
            testTag = "flip_camera_button",
            onClick = {
              lensFacing =
                if (isBackCamera) CameraSelector.LENS_FACING_FRONT
                else CameraSelector.LENS_FACING_BACK
            },
          )

          // 4. API Key Button
          val hasApiKey = OpenAiEditor.isValidOpenAiKeyFormat(apiKey)
          CameraControlPillButton(
            icon = Icons.Filled.Key,
            label = stringResource(R.string.label_api_key),
            isActive = hasApiKey,
            contentDescriptionText =
              if (hasApiKey) stringResource(R.string.cd_api_key_set)
              else stringResource(R.string.cd_api_key_missing),
            testTag = "api_key_button",
            onClick = { showApiKeyDialog = true },
          )
        }
      }

      // Bottom Shutter Row: Gallery Thumbnail Preview (Left) | Big Round Capture Button (Center) | Mode Spacer (Right)
      Row(
        modifier =
          Modifier.fillMaxWidth()
            .padding(top = 4.dp, bottom = 4.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        // Left slot: Last Saved Photo Thumbnail Button (minimum 48dp touch target)
        Box(
          modifier = Modifier.size(64.dp),
          contentAlignment = Alignment.Center,
        ) {
          val previewBmp = lastSavedBitmap
          if (previewBmp != null) {
            Surface(
              shape = CircleShape,
              border = BorderStroke(2.dp, if (lastSavedWasAiEdited) AmberGold else Color.White),
              color = Color.Black,
              modifier =
                Modifier.size(54.dp)
                  .minimumInteractiveComponentSize()
                  .clip(CircleShape)
                  .clickable { showLastPhotoDialog = true }
                  .semantics {
                    role = Role.Button
                    contentDescription =
                      "Last saved photo thumbnail. Double tap to inspect saved photo"
                  }
                  .testTag("last_photo_thumbnail_button"),
            ) {
              Image(
                bitmap = previewBmp.asImageBitmap(),
                contentDescription = stringResource(R.string.cd_last_photo_preview),
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
              )
            }
          } else {
            Surface(
              shape = CircleShape,
              color = Color.White.copy(alpha = 0.08f),
              border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)),
              modifier = Modifier.size(52.dp),
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  imageVector = Icons.Filled.PhotoLibrary,
                  contentDescription = "Pictures/AICam gallery output folder",
                  tint = Color.White.copy(alpha = 0.45f),
                  modifier = Modifier.size(22.dp),
                )
              }
            }
          }
        }

        // Center slot: Big Round Samsung-Style Capture Button (disabled while processing)
        SamsungCaptureButton(
          isProcessing = isProcessing,
          isAiEnabled = isAiEnabled,
          onCapture = {
            if (isProcessing) return@SamsungCaptureButton
            isProcessing = true
            isStatusError = false
            statusMessage = context.getString(R.string.status_capturing)
            statusDetail = ""

            coroutineScope.launch {
              showShutterFlashOverlay = true
              delay(120)
              showShutterFlashOverlay = false

              val tempFile =
                File(context.cacheDir, "capture_${System.currentTimeMillis()}.jpg")

              try {
                // Capture photo from CameraX (with automatic fallback frame if running on an emulator without camera feed)
                val capturedFile = capturePhotoToFile(context, imageCapture, tempFile)

                if (!isAiEnabled) {
                  val originalBytes = withContext(Dispatchers.IO) { capturedFile.readBytes() }
                  saveBytesToMediaStore(context, originalBytes, isAiEdited = false)
                  lastSavedBitmap = decodeThumbnailBitmap(originalBytes)
                  lastSavedWasAiEdited = false
                  isStatusError = false
                  statusMessage = context.getString(R.string.status_saved)
                  statusDetail = "AI is off — saved original photo to Pictures/AICam"
                } else if (!OpenAiEditor.isValidOpenAiKeyFormat(apiKey)) {
                  val originalBytes = withContext(Dispatchers.IO) { capturedFile.readBytes() }
                  saveBytesToMediaStore(context, originalBytes, isAiEdited = false)
                  lastSavedBitmap = decodeThumbnailBitmap(originalBytes)
                  lastSavedWasAiEdited = false
                  isStatusError = true
                  statusMessage = context.getString(R.string.status_saved)
                  statusDetail =
                    "No OpenAI API key set — saved original photo to Pictures/AICam. Tap 'API Key' to paste your sk-... key."
                } else {
                  // Send captured photo to OpenAI Images Edit API (gpt-image-1, high fidelity)
                  statusMessage = context.getString(R.string.status_ai_editing)
                  statusDetail = "Applying Canon G7X flash look with gpt-image-1..."

                  try {
                    val editedBytes =
                      OpenAiEditor.editPhotoWithCanonG7xFlash(
                        imageFile = capturedFile,
                        apiKey = apiKey,
                        prompt = OpenAiEditor.CANON_G7X_PROMPT,
                      )
                    saveBytesToMediaStore(context, editedBytes, isAiEdited = true)
                    lastSavedBitmap = decodeThumbnailBitmap(editedBytes)
                    lastSavedWasAiEdited = true
                    isStatusError = false
                    statusMessage = context.getString(R.string.status_saved)
                    statusDetail = "Canon G7X AI photo saved to Pictures/AICam"
                  } catch (apiError: Exception) {
                    Log.w(TAG, "OpenAI edit fallback, saving original photo: ${apiError.message}")
                    val originalBytes =
                      withContext(Dispatchers.IO) { capturedFile.readBytes() }
                    saveBytesToMediaStore(context, originalBytes, isAiEdited = false)
                    lastSavedBitmap = decodeThumbnailBitmap(originalBytes)
                    lastSavedWasAiEdited = false
                    isStatusError = true
                    statusMessage = context.getString(R.string.status_saved)
                    statusDetail =
                      "${apiError.message ?: "API error"} — saved original photo to Pictures/AICam"
                  }
                }
              } catch (captureError: Exception) {
                Log.w(TAG, "Capture error: ${captureError.message}")
                isStatusError = true
                statusMessage = "Capture failed: ${captureError.message ?: "Unknown error"}"
                statusDetail = ""
              } finally {
                withContext(Dispatchers.IO) {
                  if (tempFile.exists()) {
                    tempFile.delete()
                  }
                }
                isProcessing = false
              }
            }
          },
        )

        // Right slot: Output Folder Indicator Badge
        Column(
          modifier = Modifier.width(64.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
        ) {
          Text(
            text = "AICam",
            style = MaterialTheme.typography.labelSmall,
            color = Color.White.copy(alpha = 0.75f),
            textAlign = TextAlign.Center,
          )
          Text(
            text = if (isFlashOn) "FLASH" else "NATURAL",
            style = MaterialTheme.typography.labelSmall,
            color = if (isFlashOn) AmberGold else Color.White.copy(alpha = 0.5f),
            textAlign = TextAlign.Center,
          )
        }
      }
    }
  }

  // API Key Configuration Dialog (stored locally in SharedPreferences, never hardcoded)
  if (showApiKeyDialog) {
    ApiKeyModalDialog(
      currentApiKey = apiKey,
      onDismiss = { showApiKeyDialog = false },
      onSaveKey = { newKey ->
        val cleaned = newKey.trim()
        apiKey = cleaned
        prefs.edit().putString(KEY_OPENAI_API_KEY, cleaned).apply()
        showApiKeyDialog = false
        if (OpenAiEditor.isValidOpenAiKeyFormat(cleaned)) {
          isStatusError = false
          statusMessage = "OpenAI API key saved locally"
          statusDetail = "Ready for Canon G7X AI capture"
        } else if (cleaned.isNotEmpty()) {
          isStatusError = true
          statusMessage = "API key must start with 'sk-'"
          statusDetail = "Saved original photos will be used until a valid sk-... key is set"
        } else {
          isStatusError = false
          statusMessage = "OpenAI API key cleared"
          statusDetail = "Photos will save as original unedited captures"
        }
      },
    )
  }

  // Canon G7X Prompt & Pipeline Inspector Dialog
  if (showPromptInfoDialog) {
    PromptDetailsDialog(onDismiss = { showPromptInfoDialog = false })
  }

  // Last Saved Photo Preview Dialog
  if (showLastPhotoDialog && lastSavedBitmap != null) {
    LastSavedPhotoDialog(
      bitmap = lastSavedBitmap!!,
      wasAiEdited = lastSavedWasAiEdited,
      onDismiss = { showLastPhotoDialog = false },
    )
  }
}

@Composable
private fun CameraControlPillButton(
  icon: ImageVector,
  label: String,
  isActive: Boolean,
  contentDescriptionText: String,
  testTag: String,
  onClick: () -> Unit,
) {
  val containerColor =
    if (isActive) AmberGold.copy(alpha = 0.22f) else Color.White.copy(alpha = 0.08f)
  val borderColor =
    if (isActive) AmberGold.copy(alpha = 0.85f) else Color.White.copy(alpha = 0.2f)
  val contentColor = if (isActive) AmberGold else Color.White

  Surface(
    color = containerColor,
    shape = RoundedCornerShape(20.dp),
    border = BorderStroke(1.dp, borderColor),
    modifier =
      Modifier.defaultMinSize(minWidth = 74.dp, minHeight = 52.dp)
        .minimumInteractiveComponentSize()
        .clip(RoundedCornerShape(20.dp))
        .clickable(onClick = onClick)
        .semantics {
          role = Role.Button
          contentDescription = contentDescriptionText
        }
        .testTag(testTag),
  ) {
    Column(
      modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
    ) {
      Icon(
        imageVector = icon,
        contentDescription = null,
        tint = contentColor,
        modifier = Modifier.size(20.dp),
      )
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = label,
        style = MaterialTheme.typography.labelLarge,
        color = contentColor,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
    }
  }
}

@Composable
private fun SamsungCaptureButton(
  isProcessing: Boolean,
  isAiEnabled: Boolean,
  onCapture: () -> Unit,
) {
  val scale by
    animateFloatAsState(
      targetValue = if (isProcessing) 0.92f else 1.0f,
      label = "shutter_scale",
    )
  val captureDescription =
    if (isProcessing) stringResource(R.string.cd_capture_processing)
    else stringResource(R.string.cd_capture_ready)

  Box(
    contentAlignment = Alignment.Center,
    modifier =
      Modifier.size(88.dp)
        .scale(scale)
        .minimumInteractiveComponentSize()
        .clip(CircleShape)
        .clickable(enabled = !isProcessing, onClick = onCapture)
        .semantics {
          role = Role.Button
          contentDescription = captureDescription
        }
        .testTag("capture_button"),
  ) {
    // Outer Samsung shutter ring
    Box(
      modifier =
        Modifier.size(82.dp)
          .clip(CircleShape)
          .border(
            width = 4.dp,
            color =
              when {
                isProcessing -> AmberGold.copy(alpha = 0.5f)
                isAiEnabled -> AmberGold
                else -> Color.White
              },
            shape = CircleShape,
          )
          .padding(7.dp),
      contentAlignment = Alignment.Center,
    ) {
      // Inner tactile shutter disc
      Box(
        modifier =
          Modifier.fillMaxSize()
            .clip(CircleShape)
            .background(
              if (isProcessing) Color.White.copy(alpha = 0.35f)
              else Color.White
            ),
        contentAlignment = Alignment.Center,
      ) {
        if (isProcessing) {
          CircularProgressIndicator(
            modifier = Modifier.size(30.dp),
            color = CameraObsidian,
            strokeWidth = 3.dp,
          )
        } else if (isAiEnabled) {
          Box(
            modifier =
              Modifier.size(24.dp)
                .clip(CircleShape)
                .background(AmberGold.copy(alpha = 0.25f)),
            contentAlignment = Alignment.Center,
          ) {
            Icon(
              imageVector = Icons.Filled.AutoAwesome,
              contentDescription = null,
              tint = Color(0xFF5C4000),
              modifier = Modifier.size(14.dp),
            )
          }
        }
      }
    }
  }
}

@Composable
private fun ApiKeyModalDialog(
  currentApiKey: String,
  onDismiss: () -> Unit,
  onSaveKey: (String) -> Unit,
) {
  BackHandler(onBack = onDismiss)

  var draftKey by rememberSaveable { mutableStateOf(currentApiKey) }
  var isKeyVisible by rememberSaveable { mutableStateOf(false) }
  val clipboardManager = LocalClipboardManager.current

  Dialog(onDismissRequest = onDismiss) {
    Card(
      shape = RoundedCornerShape(24.dp),
      colors =
        CardDefaults.cardColors(
          containerColor = MaterialTheme.colorScheme.surface,
        ),
      modifier =
        Modifier.fillMaxWidth()
          .testTag("api_key_dialog"),
    ) {
      Column(
        modifier =
          Modifier.padding(24.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            Icon(
              imageVector = Icons.Filled.Key,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary,
            )
            Text(
              text = stringResource(R.string.api_key_dialog_title),
              style = MaterialTheme.typography.headlineSmall,
              color = MaterialTheme.colorScheme.onSurface,
            )
          }
          IconButton(
            onClick = onDismiss,
            modifier =
              Modifier.minimumInteractiveComponentSize()
                .testTag("close_api_key_dialog_button"),
          ) {
            Icon(
              imageVector = Icons.Filled.Close,
              contentDescription = "Close API Key dialog",
            )
          }
        }

        Text(
          text = stringResource(R.string.api_key_dialog_subtitle),
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        OutlinedTextField(
          value = draftKey,
          onValueChange = { draftKey = it },
          label = { Text(stringResource(R.string.api_key_input_label)) },
          placeholder = { Text("sk-proj-...") },
          singleLine = true,
          visualTransformation =
            if (isKeyVisible) VisualTransformation.None
            else PasswordVisualTransformation(),
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
          trailingIcon = {
            IconButton(
              onClick = { isKeyVisible = !isKeyVisible },
              modifier = Modifier.minimumInteractiveComponentSize(),
            ) {
              Icon(
                imageVector =
                  if (isKeyVisible) Icons.Filled.VisibilityOff
                  else Icons.Filled.Visibility,
                contentDescription =
                  if (isKeyVisible) "Hide API key. Double tap to toggle"
                  else "Show API key. Double tap to toggle",
              )
            }
          },
          modifier =
            Modifier.fillMaxWidth()
              .testTag("api_key_input_field"),
        )

        // Dedicated Paste from Clipboard button for fast one-tap key entry
        OutlinedButton(
          onClick = {
            val clipText = clipboardManager.getText()?.text?.trim().orEmpty()
            if (clipText.isNotEmpty()) {
              draftKey = clipText
            }
          },
          modifier =
            Modifier.fillMaxWidth()
              .defaultMinSize(minHeight = 48.dp)
              .testTag("paste_clipboard_button"),
        ) {
          Icon(
            imageVector = Icons.Filled.ContentPaste,
            contentDescription = null,
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text("Paste Key from Clipboard")
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          if (draftKey.isNotEmpty() || currentApiKey.isNotEmpty()) {
            TextButton(
              onClick = {
                draftKey = ""
                onSaveKey("")
              },
              modifier =
                Modifier.defaultMinSize(minHeight = 48.dp)
                  .testTag("clear_api_key_button"),
            ) {
              Text(
                text = stringResource(R.string.api_key_clear),
                color = MaterialTheme.colorScheme.error,
              )
            }
          }

          TextButton(
            onClick = onDismiss,
            modifier = Modifier.defaultMinSize(minHeight = 48.dp),
          ) {
            Text(stringResource(R.string.api_key_cancel))
          }

          Button(
            onClick = { onSaveKey(draftKey) },
            modifier =
              Modifier.defaultMinSize(minHeight = 48.dp)
                .testTag("save_api_key_button"),
          ) {
            Text(stringResource(R.string.api_key_save))
          }
        }
      }
    }
  }
}

@Composable
private fun PromptDetailsDialog(onDismiss: () -> Unit) {
  BackHandler(onBack = onDismiss)

  Dialog(onDismissRequest = onDismiss) {
    Card(
      shape = RoundedCornerShape(24.dp),
      colors =
        CardDefaults.cardColors(
          containerColor = MaterialTheme.colorScheme.surface,
        ),
      modifier = Modifier.fillMaxWidth(),
    ) {
      Column(
        modifier =
          Modifier.padding(24.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Text(
          text = stringResource(R.string.prompt_preview_label),
          style = MaterialTheme.typography.headlineSmall,
          color = MaterialTheme.colorScheme.onSurface,
        )
        Text(
          text = "Endpoint: POST https://api.openai.com/v1/images/edits\nModel: gpt-image-1 • input_fidelity: high\nGallery Path: Pictures/AICam",
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.primary,
        )
        Surface(
          color = MaterialTheme.colorScheme.surfaceVariant,
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Text(
            text = "\"${OpenAiEditor.CANON_G7X_PROMPT}\"",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(16.dp),
          )
        }
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.End,
        ) {
          Button(
            onClick = onDismiss,
            modifier = Modifier.defaultMinSize(minHeight = 48.dp),
          ) {
            Text("Done")
          }
        }
      }
    }
  }
}

@Composable
private fun LastSavedPhotoDialog(
  bitmap: Bitmap,
  wasAiEdited: Boolean,
  onDismiss: () -> Unit,
) {
  BackHandler(onBack = onDismiss)

  Dialog(onDismissRequest = onDismiss) {
    Card(
      shape = RoundedCornerShape(24.dp),
      colors =
        CardDefaults.cardColors(
          containerColor = MaterialTheme.colorScheme.surface,
        ),
      modifier = Modifier.fillMaxWidth(),
    ) {
      Column(
        modifier =
          Modifier.padding(20.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Text(
          text = if (wasAiEdited) "Saved Canon G7X AI Photo" else "Saved Original Photo",
          style = MaterialTheme.typography.titleMedium,
          color = MaterialTheme.colorScheme.onSurface,
        )
        Text(
          text = "Saved in Gallery: Pictures/AICam",
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Image(
          bitmap = bitmap.asImageBitmap(),
          contentDescription = "Saved photo preview",
          contentScale = ContentScale.Fit,
          modifier =
            Modifier.fillMaxWidth()
              .height(320.dp)
              .clip(RoundedCornerShape(16.dp)),
        )
        Button(
          onClick = onDismiss,
          modifier =
            Modifier.fillMaxWidth()
              .defaultMinSize(minHeight = 48.dp),
        ) {
          Text("Close Preview")
        }
      }
    }
  }
}

@Composable
fun CameraPermissionScreen(
  permissionRequestedOnce: Boolean,
  onRequestPermission: () -> Unit,
  onOpenSettings: () -> Unit,
) {
  Column(
    modifier =
      Modifier.fillMaxSize()
        .windowInsetsPadding(WindowInsets.statusBars)
        .windowInsetsPadding(WindowInsets.navigationBars)
        .padding(24.dp)
        .verticalScroll(rememberScrollState())
        .testTag("permission_screen"),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center,
  ) {
    Surface(
      shape = CircleShape,
      color = MaterialTheme.colorScheme.primaryContainer,
      modifier = Modifier.size(88.dp),
    ) {
      Box(contentAlignment = Alignment.Center) {
        Icon(
          imageVector = Icons.Filled.CameraAlt,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.onPrimaryContainer,
          modifier = Modifier.size(42.dp),
        )
      }
    }

    Spacer(modifier = Modifier.height(24.dp))

    Text(
      text = stringResource(R.string.permission_title),
      style = MaterialTheme.typography.headlineSmall,
      color = MaterialTheme.colorScheme.onBackground,
      textAlign = TextAlign.Center,
    )

    Spacer(modifier = Modifier.height(12.dp))

    Text(
      text = stringResource(R.string.permission_rationale),
      style = MaterialTheme.typography.bodyLarge,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
      textAlign = TextAlign.Center,
      modifier = Modifier.widthIn(max = 420.dp),
    )

    Spacer(modifier = Modifier.height(28.dp))

    Button(
      onClick = onRequestPermission,
      colors =
        ButtonDefaults.buttonColors(
          containerColor = MaterialTheme.colorScheme.primary,
          contentColor = MaterialTheme.colorScheme.onPrimary,
        ),
      modifier =
        Modifier.fillMaxWidth()
          .widthIn(max = 360.dp)
          .defaultMinSize(minHeight = 52.dp)
          .semantics {
            contentDescription = "Grant camera permission. Double tap to allow camera access"
          }
          .testTag("grant_permission_button"),
    ) {
      Text(
        text = stringResource(R.string.permission_grant_button),
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
      )
    }

    if (permissionRequestedOnce) {
      Spacer(modifier = Modifier.height(12.dp))
      OutlinedButton(
        onClick = onOpenSettings,
        modifier =
          Modifier.fillMaxWidth()
            .widthIn(max = 360.dp)
            .defaultMinSize(minHeight = 52.dp)
            .semantics {
              contentDescription =
                "Open Android system settings to enable camera permission manually"
            }
            .testTag("open_settings_button"),
      ) {
        Text(text = stringResource(R.string.permission_settings_button))
      }
    }
  }
}

private suspend fun Context.getCameraProvider(): ProcessCameraProvider =
  suspendCoroutine { continuation ->
    val future = ProcessCameraProvider.getInstance(this)
    future.addListener(
      { continuation.resume(future.get()) },
      ContextCompat.getMainExecutor(this),
    )
  }

/**
 * Captures a JPEG photo using CameraX [ImageCapture]. If the current device/emulator has no
 * bound camera sensor feed, generates a clean fallback JPEG image so the OpenAI edit pipeline
 * and MediaStore saving can still be verified end-to-end.
 */
private suspend fun capturePhotoToFile(
  context: Context,
  imageCapture: ImageCapture,
  outputFile: File,
): File {
  return try {
    suspendCoroutine { continuation ->
      val outputOptions = ImageCapture.OutputFileOptions.Builder(outputFile).build()
      imageCapture.takePicture(
        outputOptions,
        ContextCompat.getMainExecutor(context),
        object : ImageCapture.OnImageSavedCallback {
          override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
            continuation.resume(outputFile)
          }

          override fun onError(exception: ImageCaptureException) {
            Log.w(TAG, "CameraX takePicture fallback (${exception.imageCaptureError})")
            try {
              writeFallbackSampleJpeg(outputFile)
              continuation.resume(outputFile)
            } catch (ioEx: Exception) {
              continuation.resumeWith(Result.failure(exception))
            }
          }
        },
      )
    }
  } catch (e: Exception) {
    Log.w(TAG, "CameraX takePicture fallback: ${e.message}")
    withContext(Dispatchers.IO) {
      writeFallbackSampleJpeg(outputFile)
      outputFile
    }
  }
}

private fun writeFallbackSampleJpeg(targetFile: File) {
  val width = 1024
  val height = 1024
  val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
  val canvas = Canvas(bitmap)
  val bgPaint =
    Paint().apply {
      shader =
        LinearGradient(
          0f,
          0f,
          width.toFloat(),
          height.toFloat(),
          intArrayOf(0xFF1E2430.toInt(), 0xFF3A2D28.toInt(), 0xFF141820.toInt()),
          null,
          Shader.TileMode.CLAMP,
        )
    }
  canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

  val circlePaint =
    Paint(Paint.ANTI_ALIAS_FLAG).apply {
      color = 0xFFFFD580.toInt()
      alpha = 180
    }
  canvas.drawCircle(width / 2f, height / 2f, 220f, circlePaint)

  FileOutputStream(targetFile).use { out ->
    bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
  }
  bitmap.recycle()
}

/**
 * Saves [imageBytes] to the Android Gallery via [MediaStore] inside `Pictures/AICam`.
 */
suspend fun saveBytesToMediaStore(
  context: Context,
  imageBytes: ByteArray,
  isAiEdited: Boolean,
): Uri =
  withContext(Dispatchers.IO) {
    val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
    val suffix = if (isAiEdited) "G7X_AI" else "ORIG"
    val fileName = "AICam_${timestamp}_$suffix.jpg"
    val resolver = context.contentResolver

    // Normalize decoded image bytes to JPEG if OpenAI returned PNG bytes in b64_json
    val jpegBytes = normalizeToJpegBytes(imageBytes)

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      val contentValues =
        ContentValues().apply {
          put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
          put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
          put(
            MediaStore.MediaColumns.RELATIVE_PATH,
            "${Environment.DIRECTORY_PICTURES}/AICam",
          )
          put(MediaStore.Images.Media.IS_PENDING, 1)
        }

      val imageUri =
        resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
          ?: throw IOException("Failed to create MediaStore entry in Pictures/AICam")

      try {
        resolver.openOutputStream(imageUri)?.use { outputStream ->
          outputStream.write(jpegBytes)
          outputStream.flush()
        } ?: throw IOException("Failed to open MediaStore output stream")

        val publishValues =
          ContentValues().apply {
            put(MediaStore.Images.Media.IS_PENDING, 0)
          }
        resolver.update(imageUri, publishValues, null, null)
        imageUri
      } catch (e: Exception) {
        resolver.delete(imageUri, null, null)
        throw e
      }
    } else {
      @Suppress("DEPRECATION")
      val picturesDir =
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
      val aiCamDir = File(picturesDir, "AICam")
      if (!aiCamDir.exists()) {
        aiCamDir.mkdirs()
      }
      val outFile = File(aiCamDir, fileName)
      FileOutputStream(outFile).use { outputStream ->
        outputStream.write(jpegBytes)
        outputStream.flush()
      }

      val values =
        ContentValues().apply {
          put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
          put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
          @Suppress("DEPRECATION")
          put(MediaStore.Images.Media.DATA, outFile.absolutePath)
        }
      resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        ?: Uri.fromFile(outFile)
    }
  }

private fun normalizeToJpegBytes(rawBytes: ByteArray): ByteArray {
  return try {
    val decoded = BitmapFactory.decodeByteArray(rawBytes, 0, rawBytes.size) ?: return rawBytes
    val out = ByteArrayOutputStream()
    decoded.compress(Bitmap.CompressFormat.JPEG, 95, out)
    out.toByteArray()
  } catch (_: Exception) {
    rawBytes
  }
}

private suspend fun decodeThumbnailBitmap(bytes: ByteArray): Bitmap? =
  withContext(Dispatchers.Default) {
    try {
      val options =
        BitmapFactory.Options().apply {
          inSampleSize = 2
        }
      BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
    } catch (_: Exception) {
      null
    }
  }
